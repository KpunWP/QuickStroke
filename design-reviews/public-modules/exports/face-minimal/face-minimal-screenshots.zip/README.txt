Face-only glass design revision. All results and camera content are synthetic.
45 Chromium camera-area captures: seven states x TH/EN/JA x 360px/100% and 320px/200%, plus three urgent examples.
No live camera or research data. See FACE-MINIMAL.md for limitations.

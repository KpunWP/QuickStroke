Face-only glass design revision. All results and camera content are synthetic.
36 Chromium captures: TH/EN/JA, six states, 360px/100% and 320px/200%.
No live camera or research data. See FACE-REVISION.md for limitations.
